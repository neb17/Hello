# Snake (iOS)
1. Create a new GitHub repo and upload everything in this folder (including the .github folder).
2. Open the Actions tab, pick "Build unsigned IPA", click Run workflow.
3. When it finishes, download Snake-unsigned-ipa from the run page and unzip it to get Snake.ipa.
4. Sign and install with Sideloadly or AltStore using your Apple ID.
